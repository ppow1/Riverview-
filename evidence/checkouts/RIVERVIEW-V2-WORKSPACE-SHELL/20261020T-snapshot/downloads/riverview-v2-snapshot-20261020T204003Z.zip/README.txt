Riverview V2 local preview snapshot

This package represents the active V2 browser view and its local fixture context. It does not contain live or server data. Read manifest.json first.
