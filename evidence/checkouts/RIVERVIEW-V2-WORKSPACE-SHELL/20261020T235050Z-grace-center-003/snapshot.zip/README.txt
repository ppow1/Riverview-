Riverview V2 local preview snapshot

This package represents the active V2 browser view and local fixture context. It may include the observed Grace connection state and safe history count; it excludes conversation contents, account identity, credentials, cookies, and server logs. Comms5 status is unverified when no authorized event feed is connected. Read manifest.json first.
